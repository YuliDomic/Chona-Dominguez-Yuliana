#include "InfijaaPostfija.h"
#include "stack.h"
#include <string.h>
#include <stdlib.h>

int jerarquiaOperaciones(char operador){
    switch (operador){
        case '+': return 1;
        case '-': return 1;
        case '*': return 2;
        case '/': return 2;
        case '^': return 3;
    }
    return -1;
}

int mayorIgualPrioridad(char operador1, char operador2){
    int op1 = jerarquiaOperaciones(operador1);
    int op2 = jerarquiaOperaciones(operador2);
    return op1 >= op2;
}

int esOperador(char elemento){
    return (
        elemento == '+' ||
        elemento == '-' ||
        elemento == '*' ||
        elemento == '/' ||
        elemento == '^'
    );
}

int esOperando(char elemento){
    return ((elemento >= '0' && elemento <= '9') ||
    		(elemento >= 'a' && elemento <= 'z') ||
    		(elemento >= 'A' && elemento <= 'Z'));
}

char* infijaaPostfija(char* infija){
    char elemento , operador;

    // Reserva suficiente espacio para la salida (2x por si acaso par�ntesis y espacios)
    char *postfija = malloc(sizeof(char) * (2 * strlen(infija) + 1));
    if (postfija == NULL) return NULL;

    int j = 0, i = 0;

    Stack stack;
    stack_init(&stack, free);

    int longitud = strlen(infija);

    printf("\t|    PROCESO DE LA NOTACION POSTFIJA    |\n");
    printf("Expresi�n infija: %s\n\n", infija);

    while (i < longitud){
        elemento = infija[i++];
        printf("\nProcesando elemento: '%c'\n", elemento);

        if (esOperando(elemento)){
            postfija[j++] = elemento;
            printf(" -> Es OPERANDO. Se a�ade a la salida.\n");

        } else if (esOperador(elemento)){
            printf(" -> Es OPERADOR '%c'. Inicia chequeo de prioridad...\n", elemento);

            while (stack_size(&stack) != 0) {
                char *opPtr;
                stack_pop(&stack, (void**)&opPtr);
                operador = *opPtr;
                free(opPtr);

                int op1 = jerarquiaOperaciones(operador);
                int op2 = jerarquiaOperaciones(elemento);
                int debeSacar = 0;

                /* Manejo de asociatividad: '^' es asociativo a la derecha,
                   por lo que si el operador de la pila y el leido son '^'
                   no deber�amos desapilar cuando tienen igual precedencia.
                   Para otros operadores usamos >= (mayor o igual). */
                if (operador == '^'){
                    debeSacar = (op1 > op2); // desapila s�lo si tiene estrictamente mayor prec.
                } else {
                    debeSacar = mayorIgualPrioridad(operador, elemento);
                }

                if (debeSacar){
                    postfija[j++] = operador;
                    printf("    * Desapilado: '%c' (precedencia mayor/igual). A�adido a la salida.\n", operador);
                } else {
                    // devolver operador a la pila (porque lo desapilamos para inspecci�n)
                    char *tmp = malloc(sizeof(char));
                    *tmp = operador;
                    stack_push(&stack, tmp);
                    printf("    * Pausa: '%c' (precedencia menor). Vuelve a la pila.\n", operador);
                    break;
                }
            }

            // Apilar el operador actual
            char *nuevo = malloc(sizeof(char));
            *nuevo = elemento;
            stack_push(&stack, nuevo);
            printf("  -> Se apila el nuevo operador: '%c'.\n", elemento);

        } else if (elemento == '('){

            char *tmp = malloc(sizeof(char));
            *tmp = elemento;
            stack_push(&stack, tmp);
            printf("  -> Es '('. Se apila.\n");

        } else if (elemento == ')'){

            printf("  -> Es ')'. Desapilando hasta encontrar '('...\n");
            if (stack_size(&stack) == 0){
                printf("    �Error! Par�ntesis desbalanceados: ')' sin '(' correspondiene.\n");
                break;
            }

            char *opPtr;
            stack_pop(&stack, (void**)&opPtr);
            operador = *opPtr;
            free(opPtr);

            while (stack_size(&stack) != 0 && operador != '('){
                postfija[j++] = operador;
                printf("    * Desapilado: '%c'. A�adido a la salida.\n", operador);

                stack_pop(&stack, (void**)&opPtr);
                operador = *opPtr;
                free(opPtr);
            }

            if (operador == '('){
                printf("  -> Se descart� el '('. Contin�a.\n");
            } else {
                // Si salimos por stack_size == 0 y operador no es '(' => desbalanceo
                printf("  -> Atenci�n: no se encontr� '(' correspondiente (par�ntesis desbalanceados).\n");
            }
        } else {
            // caracteres ignotos (espacios)
            if (elemento != ' ' && elemento != '\t' && elemento != '\r' && elemento != '\n'){
                printf("  Caracter no reconocido '%c' (se ignora).\n", elemento);
            }
        }

        // terminar string temporal para mostrar progreso
        postfija[j] = '\0';
        printf("  >> Salida Temporal (Postfija): %s\n", postfija);
    }

    // vaciar pila
    printf("\n--- FIN DE CADENA. Vaciando Pila ---\n");
    while (stack_size(&stack) != 0){
        char *opPtr;
        stack_pop(&stack, (void**)&opPtr);
        operador = *opPtr;
        free(opPtr);

        if (operador == '(' || operador == ')'){
            printf("  Atenci�n: par�ntesis sobrante '%c' (posible desbalanceo).\n", operador);
            continue;
        }

        postfija[j++] = operador;
        postfija[j] = '\0';
        printf("  -> Sacando de la pila: '%c'. A�adido a la salida.\n", operador);
        printf("  >> Salida Temporal (Postfija): %s\n", postfija);
    }

    postfija[j] = '\0';
    printf("\nConversi�n completada. Expresi�n POSTFIJA: %s\n", postfija);
    printf("----------------------------------------\n");

    return postfija;
}



