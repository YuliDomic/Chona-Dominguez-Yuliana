#ifndef INFIJAA_POSTFIJA_H
#define INFIJAA_POSTFIJA_H

char* infijaaPostfija(char* infija);
int jerarquiaOperaciones(char operador);
int mayorIgualPrioridad(char operador1, char operador2);
int esOperador(char elemento);
int esOperando(char elemento);

#endif

