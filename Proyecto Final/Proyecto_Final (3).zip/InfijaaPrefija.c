#include "InfijaaPostfija.h"
#include "stack.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


char* InversorDeCadena(char* str){
	int i;
	int len = strlen(str);
	
	char *nueva= strdup(str);
	if(nueva==NULL){
		return NULL;
	}
	for(i=0; i<len / 2; i++){
		char temp = nueva[i];
		nueva[i]= nueva[len - 1 - i];
		nueva[len- 1- i]= temp;
	}
	return nueva;
}

char* inversorYParentesisCambiados(char * infija){
	int i;
	int len = strlen(infija);
	char *nueva = malloc(len + 1);
	if(nueva == NULL){
			return NULL;
	}

	for(i=0; i < len; i++){
		char c = infija[len -1 -i];
		if(c == '('){
			nueva[i]= ')';
			
		}else if(c == ')'){
			nueva[i]= '(';
		}else{
			nueva[i]= c;
		}
	}
	
	nueva[len]='\0';
	return nueva;
}

char* infijaaPrefija(char* infija){
   
   char* infijaInvertida = inversorYParentesisCambiados(infija);
   if(infijaInvertida == NULL){
   	return NULL;
   }
   
   char elemento , operador;
   
   char *resultadoTemporal = malloc(sizeof(char)*(2*strlen(infija)+1));
   if(resultadoTemporal==NULL){
   	free(infijaInvertida);
   	return NULL;
   }
   
    int j = 0, i = 0;

    Stack stack;
    stack_init(&stack, free);

    int longitud = strlen(infijaInvertida);
	printf("\t|    	PROCESO DE LA NOTACION PREFIJA		|\n");
    while (i < longitud){
        elemento = infijaInvertida[i++];
		printf("\n Procesando elemeto: '%c'\n",elemento);
		
        if (esOperando(elemento)){
            resultadoTemporal[j++] = elemento;
			printf(" -> Es OPERANDO. Se a�ade a la salida.\n");
        
		} else if (esOperador(elemento)){
			printf(" -> Es OPERADOR '%c'.Inicia chequeo de prioridad...\n",elemento);
            
			
			while (stack_size(&stack) != 0) {
                char *opPtr;
                stack_pop(&stack, (void**)&opPtr);
                operador = *opPtr;
                free(opPtr);

                int op1 = jerarquiaOperaciones(operador);
                int op2 = jerarquiaOperaciones(elemento);
                int debeSacar = 0;
                
                if (operador == '^'){
                	debeSacar = (op1 > op2);
				}else{
					debeSacar = mayorIgualPrioridad(operador, elemento);
				}
				
				if(debeSacar){
					resultadoTemporal[j++] = operador;
					printf("    * Desapilado: '%c' (Precedencia mayor/igual). A�adido a la salida.\n", operador);
				}else{
					char *tmp = malloc(sizeof(char));
					*tmp = operador;
					stack_push(&stack, tmp);
					printf("    * Pausa: '%c' (Precedencia menor). Vuelve a la pila.\n", operador);
                    break;
				}
				
            }

            char *nuevo = malloc(sizeof(char));
            *nuevo = elemento;
            stack_push(&stack, nuevo);
			printf("  -> Se apila el nuevo operador: '%c'.\n", elemento);
        } else if (elemento == '(') {

            char *tmp = malloc(sizeof(char));
            *tmp = elemento;
            stack_push(&stack, tmp);
			printf("  -> Es '('. Se apila.\n");
			
			
        } else if (elemento == ')') {
        	printf("  -> Es ')'. Desapilando hasta encontrar '('.\n");

            char *opPtr;
            stack_pop(&stack, (void**)&opPtr);
            operador = *opPtr;
            free(opPtr);

            while (stack_size(&stack) != 0 && operador != '('){
                resultadoTemporal[j++] = operador;
				printf("    * Desapilado: '%c'. A�adido a la salida.\n", operador);
                
				stack_pop(&stack, (void**)&opPtr);
                operador = *opPtr;
                free(opPtr);
            }
            printf("  -> Se descart� el '('. Contin�a.\n");
        }
        
        resultadoTemporal[j] = '\0';
        printf("  >> Salida Temporal (Prefija Invertida): %s\n", resultadoTemporal);
    }

	printf("\n--- FIN DE CADENA. Vaciando Pila ---\n");
    while (stack_size(&stack) != 0){
        char *opPtr;
        stack_pop(&stack, (void**)&opPtr);
        operador = *opPtr;
        free(opPtr);

        resultadoTemporal[j++] = operador;
        printf("  -> Sacando de la pila: '%c'. A�adido a la salida.\n", operador);
    }

    resultadoTemporal[j] = '\0';
    printf("Salida Temporal COMPLETA (Prefija invertida): %s\n", resultadoTemporal);
    
    char* prefijaFinal = InversorDeCadena(resultadoTemporal);
    printf("Expresi�n PREFIJA FINAL: %s\n", prefijaFinal);
    printf("----------------------------------------\n");
    
    free(infijaInvertida); 
    free(resultadoTemporal); 

    return prefijaFinal;
}

