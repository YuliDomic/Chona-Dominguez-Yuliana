#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stack.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>  

int ConfiguraIdioma()
{
	//Cambia al idioma Espa�ol   
	struct lconv *lcPtr;
	setlocale(LC_ALL, "spanish");
	lcPtr = localeconv();

	//Configura cantidades para M�xico
	lcPtr->decimal_point = ".";
	lcPtr->thousands_sep = ",";
	lcPtr->grouping = "3";	
}


// Declaraci�n de tu funci�n
char* infijaaPostfija(char* infija);
char* infijaaPrefija(char* infija);

int main() {
	
	ConfiguraIdioma();
	printf("\t....................Proyecto Final......................\n");
	printf("\t           	  Estructura de Datos   \n");
	printf("\t     'Calculadora de notaci�n Prefija y Posfija'    \n");
	printf("\t           	     Integrantes:   \n");
	printf("\t      	      Chona Dominguez Yuliana   \n");
	printf("\t     	      L�pez Zamora Ingrid Yaran�   \n\n");


	printf("\tEl objetivo de este programa es hacer uso de las notaciones\n");
    printf("\tinfija, prefija y posfija, las cuales son formas de escribir\n");
    printf("\texpresiones matem�ticas que se diferencian por la posici�n\n");
    printf("\tdel operador con respecto a los operandos. Estas notaciones\n");
    printf("\tfacilitan que la computadora realice operaciones sin\n");
    printf("\tnecesidad de par�ntesis ni reglas complejas.\n\n");

    printf("\tResumen de cada notaci�n:\n\n");

    printf("\tNotaci�n Infija: a + b\n");
    printf("\t   Es la forma com�n utilizada por las personas al escribir\n");
    printf("\t   operaciones, colocando el operador entre los operandos.\n\n");

    printf("\tNotaci�n Prefija: + a b\n");
    printf("\t   En esta notaci�n el operador va antes de los operandos.\n");
    printf("\t   No requiere par�ntesis, ya que el orden determina c�mo\n");
    printf("\t   se eval�a la expresi�n. Es f�cil de procesar por las PC.\n\n");

    printf("\tNotaci�n Posfija: a b +\n");
    printf("\t   El operador va despu�s de los operandos. Es eficiente\n");
    printf("\t   para calculadoras, pues elimina par�ntesis y mantiene\n");
    printf("\t   el  orden de los operados y operandos,  y por lo tanto \n");
	printf("\t   estos son claros al momento  de la evaluaci�n.\n\n");
	
	system("pause");
	
    char infija[100];

    printf("\n\nIngresa la expresion infija: ");
    scanf("%s", infija);

    char *postfija = infijaaPostfija(infija);
    char *prefija = infijaaPrefija(infija);
    
    system("pause");

    free(postfija);
    free(prefija);

    return 0;
}

